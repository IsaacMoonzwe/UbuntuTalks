<?php defined('SYSTEM_INIT') or die('Invalid Usage.');
echo html_entity_decode($epage);