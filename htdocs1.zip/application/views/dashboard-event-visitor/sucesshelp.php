<?php defined('SYSTEM_INIT') or die('Invalid Usage.'); ?>
<!-- [ PAGE ========= -->
<!-- <main class="page"> -->
<div class="container container--fixed">
    <div class="page__head">
        <h1>Support Help</h1>
    </div>
    <div class="page__body">
            <div class="page-content">
                 <div class="wallet-box page-container margin-top-5 margin-bottom-5 padding-8">
                    <div class="row justify-content-between align-items-center">
                      <div class="col-sm-12">
                       <div>Email Send sucessfully</div>
                    </div>
                </div>
        </div>
    </div>
</div>
  