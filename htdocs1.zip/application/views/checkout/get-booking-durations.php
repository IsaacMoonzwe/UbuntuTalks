<?php

defined('SYSTEM_INIT') or die('Invalid Usage.');
if ($cartData['lpackage_is_free_trial'] == 0) {
    ?>
<?php } ?>