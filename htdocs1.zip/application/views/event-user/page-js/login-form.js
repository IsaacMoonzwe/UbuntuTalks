$(document).ready(function(){
	sessionStorage.removeItem("cometChatUserExists");
	localStorage.removeItem("cometPrivateChatUserExists");
})