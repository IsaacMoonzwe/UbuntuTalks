/* (function() {
	setupContribution = function(frm){
		if (!$(frm).validate()) return;
		var data = fcom.frmData(frm);
		fcom.updateWithAjax(fcom.makeUrl('Blog','setupContribution'), data, function(res){
			
		});
		return false;
	};
})(); */