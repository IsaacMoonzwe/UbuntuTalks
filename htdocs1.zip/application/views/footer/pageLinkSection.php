<?php defined('SYSTEM_INIT') or die('Invalid Usage.'); ?>
<div class="col-md-6 col-lg-3">
    <div class="footer-group toggle-group">
        <div class="footer__group-title toggle-trigger-js">
            <h5 class="">Links</h5>
        </div>
        <div class="footer__group-content toggle-target-js">
            <div class="bullet-list">
                <ul>
                <li>
                        <a target="_self" href="/contact" class="bullet-list__action">Contact</a>
                    </li>
                    <li>
                        <a target="_self" href="/online-classes" class="bullet-list__action">Groups</a>
                    </li>
                    <li>
                        <a target="_self" href="/apply-to-teach" class="bullet-list__action">Teach</a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>