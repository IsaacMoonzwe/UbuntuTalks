<?php

$ctrl = new ErrorController('index');
$ctrl->index();
exit;
